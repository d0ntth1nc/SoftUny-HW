﻿
namespace BankOfKurtovoKonare
{
    public enum CustomerType { Individual, Company }
}
