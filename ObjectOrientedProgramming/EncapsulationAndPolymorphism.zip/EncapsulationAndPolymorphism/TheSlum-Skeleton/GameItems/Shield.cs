﻿
namespace TheSlum.GameItems
{
    public class Shield : Item
    {
        public Shield(string id)
            : base(id, 0, 50, 0) { }
    }
}
