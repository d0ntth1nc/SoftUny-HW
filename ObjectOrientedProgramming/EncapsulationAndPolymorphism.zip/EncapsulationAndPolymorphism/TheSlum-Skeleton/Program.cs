﻿using System;
using TheSlum.GameEngine;

namespace TheSlum
{
    public class Program
    {
        static void Main(string[] args)
        {
            var engine = new GameEngine.GameEngine();
            engine.Run();
        }
    }
}
