﻿
namespace ClassStudent
{
    class StudentsSpecialty
    {
        public string SpecialtyName { get; set; }
        public int FaciltyNumber { get; set; }
    }
}
