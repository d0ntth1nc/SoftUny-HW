﻿
namespace School
{
    public class Discipline
    {
        public string Name { get; set; }
        public int LecturesCount { get; set; }
        public Student[] Students { get; set; }
        public string Details { get; set; }
    }
}
