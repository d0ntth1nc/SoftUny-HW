﻿
namespace School
{
    public class Class
    {
        public Teacher[] Teachers { get; set; }
        public string Name { get; set; }
        public string Details { get; set; }
    }
}
