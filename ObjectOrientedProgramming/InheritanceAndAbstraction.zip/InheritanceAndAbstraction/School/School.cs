﻿
namespace School
{
    public class School
    {
        public Class[] Classes { get; set; }
    }
}
