﻿
namespace CompanyHierarchy
{
    public enum ProjectState { Open, Closed }
}
