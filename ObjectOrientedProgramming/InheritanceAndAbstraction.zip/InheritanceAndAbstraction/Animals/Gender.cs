﻿
namespace Animals
{
    enum Gender { Male, Female }
}
