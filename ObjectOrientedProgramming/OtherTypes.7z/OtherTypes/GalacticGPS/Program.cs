﻿using System;

namespace GalacticGPS
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(new Location(18.037986, 28.870097, Planet.Earth));
        }
    }
}
