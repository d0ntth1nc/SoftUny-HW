﻿
namespace GalacticGPS
{
    internal enum Planet
    {
        Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
    }
}
