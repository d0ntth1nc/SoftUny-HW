﻿
namespace Animals
{
    interface ISound
    {
        void ProduceSound();
    }
}
