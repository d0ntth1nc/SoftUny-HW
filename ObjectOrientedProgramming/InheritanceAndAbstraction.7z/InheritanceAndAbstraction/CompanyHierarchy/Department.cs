﻿
namespace CompanyHierarchy
{
    public enum Department { Production, Accounting, Sales, Marketing }
}
