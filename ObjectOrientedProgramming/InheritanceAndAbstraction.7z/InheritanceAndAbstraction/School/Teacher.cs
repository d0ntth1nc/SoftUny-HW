﻿
namespace School
{
    public class Teacher : Human
    {
        public Discipline[] Disciplines { get; set; }
        public string Details { get; set; }
    }
}
