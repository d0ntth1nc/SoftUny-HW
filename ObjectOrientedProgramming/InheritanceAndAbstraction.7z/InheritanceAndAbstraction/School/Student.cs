﻿
namespace School
{
    public class Student : Human
    {
        public int ClassNumber { get; set; }
        public string Details { get; set; }
    }
}
