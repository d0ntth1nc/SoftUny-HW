﻿
namespace School
{
    public abstract class Human
    {
        public string Name { get; set; }
    }
}
